﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SliderScript : MonoBehaviour {

    Slider slider;
    float level;

    void Start () {
        slider = GameObject.Find("Slider").GetComponent<Slider>();
        slider.value = 0;
        level = slider.value;
    }

    void Update ()
    {
        Debug.Log (slider.value.ToString());
    }
}