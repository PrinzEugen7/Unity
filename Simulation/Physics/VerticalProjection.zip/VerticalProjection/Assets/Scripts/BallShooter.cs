﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BallShooter : MonoBehaviour {
    float yMax = 0;	// DistanceTextオブジェクトへの参照

	// DistanceTextオブジェクトへの参照
	GameObject textObject;

	// DistanceTextオブジェクトのTextコンポーネントへの参照をキャッシュ
    Text scoreText;



	void Start () {
		// 初速
    	float INIT_SPEED = 20f;
		
		// Rigidbodyコンポーネントへの参照を取得
		Rigidbody rb = gameObject.GetComponent<Rigidbody>();

		// 初速を与える
		Vector3 vel = Vector3.zero;
		vel.y = INIT_SPEED;
		rb.velocity = vel;
		textObject = GameObject.Find("Text");
		scoreText = textObject.GetComponent<Text>();
	}

    void FixedUpdate(){
		// コンソールに高さyを出力
		if(gameObject.transform.position.y > yMax){
		    yMax = gameObject.transform.position.y;
		}
	    scoreText.text = "Max：" + yMax.ToString();
    }

	void Update () {
		
	}
}
