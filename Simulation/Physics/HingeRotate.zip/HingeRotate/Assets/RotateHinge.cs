﻿using UnityEngine;
using System.Collections;

public class RotateHinge : MonoBehaviour {

	// 
	private GameObject CapsuleBottom;

	// 初期設定
	void Start () {
		CapsuleBottom = GameObject.Find ("Capsule1");
	}
	
	// フレームごとに呼び出し
	void Update () {
		CapsuleBottom.transform.Rotate(2,0,0);
	}

}
